<?php
    $empfaenger = "e.royanian@gmail.com";  // Bitte tragen Sie hier Ihre E-Mail Adresse ein. (zwischen den Anf�hrungszeichen)
    $ihrname = "Royan Trading GmbH"; // Bitte tragen Sie hier Ihren Namen ein. (zwischen den Anf�hrungszeichen) Dieser erscheint als Absender in der Danke Mail.
    
    
    $danke = "danke.php";  // Pfad zur Danke Seite. "danke.php" kann durch einen Link/URL ersetzt werden. (muss mit "http://www." anfangen!)
    
    
    
    // Maximale Zeichenl�nge der Felder definieren //
    
    $zeichenlaenge_name = "50";  // Maximale Zeichen - Feld "Name" (zwischen den Anf�hrungszeichen)
    
    $zeichenlaenge_email = "50"; // Maximale Zeichen - Feld "E-Mail" (zwischen den Anf�hrungszeichen)
    
    $zeichenlaenge_ort = "50"; // Maximale Zeichen - Feld "Ort" (zwischen den Anf�hrungszeichen)
    
    $zeichenlaenge_telefon = "50"; // Maximale Zeichen - Feld "Telefon" (zwischen den Anf�hrungszeichen)
    
    $zeichenlaenge_betreff = "50"; // Maximale Zeichen - Feld "Betreff" (zwischen den Anf�hrungszeichen)
?> 