<?php
/*
-----------------
Language: German
-----------------
*/

$lang = array();

$lang['PAGE_TITLE'] = 'Royan Trading GmbH';
$lang['HEADER_TITLE'] = 'Royan Trading GmbH';
$lang['SITE_NAME'] = 'Royan Trading GmbH';

// Menu

$lang['MENU_HOME'] = 'Startseite';
$lang['MENU_Services'] = 'Leistungen';
$lang['MENU_Solution'] = 'Lösungen';
$lang['MENU_About Us'] = 'Über uns';
$lang['MENU_Contact'] = 'Kontakt';
?>