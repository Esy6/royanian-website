<?php
/*
------------------
Language: English
------------------
*/

$lang = array();

$lang['PAGE_TITLE'] = 'Royan Trading GmbH';
$lang['HEADER_TITLE'] = 'Royan Trading GmbH';
$lang['SITE_NAME'] = 'Royan Trading GmbH';

// Menu

$lang['MENU_HOME'] = 'Home';
$lang['MENU_Services'] = 'Services';
$lang['MENU_Solution'] = 'Solution';
$lang['MENU_About Us'] = 'About Us';
$lang['MENU_Contact']  = 'Contact';
?>